package com.yash.ophs.service;

import java.util.List;
import com.yash.ophs.model.PatientMedicianhistory;


public interface PatientMedicineHistoryService 
{
	public List<PatientMedicianhistory> getAllPatientMedicineHistory();
}
