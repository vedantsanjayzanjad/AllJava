package com.yash.ophs.service;

import java.util.List;

import com.yash.ophs.model.PatientHospitalHistory;


public interface PhHistoryService {

	public List<PatientHospitalHistory> getAllPhHistory();
}
