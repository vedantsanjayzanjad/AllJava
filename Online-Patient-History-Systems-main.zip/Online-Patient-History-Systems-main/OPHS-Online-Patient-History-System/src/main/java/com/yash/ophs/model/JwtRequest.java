//package com.yash.ophs.model;
//
//public class JwtRequest {
//
//	String adminName;
//	String userPassword;
//	
//	public JwtRequest()
//	{
//		
//	}
//
//	public JwtRequest(String adminName, String userPassword) {
//		super();
//		this.adminName = adminName;
//		this.userPassword = userPassword;
//	}
//
//	public String getAdminName() {
//		return adminName;
//	}
//
//	public void setAdminName(String adminName) {
//		this.adminName = adminName;
//	}
//
//	public String getUserPassword() {
//		return userPassword;
//	}
//
//	public void setUserPassword(String userPassword) {
//		this.userPassword = userPassword;
//	}
//	
//	
//	
//}
