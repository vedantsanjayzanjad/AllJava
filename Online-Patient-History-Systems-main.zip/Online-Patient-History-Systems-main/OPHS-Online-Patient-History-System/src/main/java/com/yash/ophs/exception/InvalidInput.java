package com.yash.ophs.exception;

public class InvalidInput 
{

}
