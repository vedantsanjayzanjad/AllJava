package com.yash.ophs.service;

import java.util.List;

import com.yash.ophs.model.PatientAllergyHistory;
public interface PatientAllergyHistoryService 
{
	public List<PatientAllergyHistory> getPaHistory();
}
