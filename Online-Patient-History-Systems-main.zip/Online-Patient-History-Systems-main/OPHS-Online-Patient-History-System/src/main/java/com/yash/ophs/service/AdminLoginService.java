package com.yash.ophs.service;

import java.util.List;

import com.yash.ophs.model.AdminLogin;

public interface AdminLoginService {

//	public void saveOrUpdate(AdminLogin al);
//
//	public List<AdminLogin> getAllAdminDetails();
//
//	public void delete(int adminId);
//
//	public void updatePatient(int adminId, AdminLogin al);

//	public AdminLogin fetchAdminByEmailIdAndPassword(String adminName, String userPassword);

}
