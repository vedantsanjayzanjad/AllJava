export class RoomType
{
    roomTypeId:'';
    roomTypeName:'';
    pricePerDay:';'
}