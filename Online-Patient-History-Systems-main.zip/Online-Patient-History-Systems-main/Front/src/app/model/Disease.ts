export class Disease
{
    diseaseId: '';
    diseaseName: '';    
}