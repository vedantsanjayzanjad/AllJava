export class Medicine
{
    tabletId:'';
    tabletName:'';
    tabletPrice:'';
    tabletQuantity:'';
    price:'';
}