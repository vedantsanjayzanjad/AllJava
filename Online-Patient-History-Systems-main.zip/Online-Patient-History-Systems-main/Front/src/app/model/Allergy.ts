export class Allergy
{
    aId:'';
    allergyName:'';
    allergyType:'';
}