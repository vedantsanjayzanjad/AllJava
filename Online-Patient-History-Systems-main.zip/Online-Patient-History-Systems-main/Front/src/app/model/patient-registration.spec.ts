import { PatientRegistration } from './patient-registration';

describe('PatientRegistration', () => {
  it('should create an instance', () => {
    expect(new PatientRegistration()).toBeTruthy();
  });
});
