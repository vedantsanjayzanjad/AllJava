export class Doctor
{
     doctorId: '';
      doctorName: '';
      doctorMobileNumber: '';
      doctorAge: '';
      doctorGender: '';
      doctorQualification: '';
      doctorSpecification: '';
}