export class Hospital
{
  	 hospitalId:'';
	 hospitalName:'';
	 hospitalAddress:'';
	 hospitalCreatedDate:'';
	 hospitalCharges:'';
}