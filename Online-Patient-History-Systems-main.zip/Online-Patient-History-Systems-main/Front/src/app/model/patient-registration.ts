export class PatientRegistration {
    patientId: number = 0

    emailId: string = '';

    password: string = '';

    patientFirstName: string = '';

    patientLastName: string = '';

    patientAddress: string = '';

    dob: string = '';

    gender: string = '';

    bloodGroup: string = '';

    mobileNumber: number = 0;

    relativeName: string = '';

    relativeMobileNumber: number = 0;

    relationWithPatient: string = '';

    roleId: number = 0;
}

